module.exports = {
  apps : [{
    name   : "downdetector-api",
    script : "./index.js"
  }]
}
